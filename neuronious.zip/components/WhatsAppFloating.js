const WhatsApp = () => {
  return (
    <div className="fixed z-[40] bottom-8 right-8">
      <a href="http://wa.me/+923001008922" target="_blank" rel="noreferrer">
        <img src="/icons/whatsapp_2.svg" className="w-12" />
      </a>
    </div>
  );
};

export default WhatsApp;
